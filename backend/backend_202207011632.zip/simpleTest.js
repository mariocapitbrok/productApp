const config = require('./utils/config')

console.log(config.PORT, config.MONGODB_URI)
