const ProductsFooter = () => {
  return <></>
}

export default ProductsFooter
