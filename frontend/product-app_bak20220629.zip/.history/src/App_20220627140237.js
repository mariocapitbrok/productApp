import logo from './logo.svg'

function App() {
  return (
    <div>
      <h1>Hello Mario</h1>
    </div>
  )
}

export default App
