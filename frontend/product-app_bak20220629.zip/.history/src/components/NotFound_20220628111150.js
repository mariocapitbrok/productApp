const NotFound = () => {
  return ( <h1>404 Not Found</h1> );
}
 
export default NotFou<h1>404 Not Found</h1>nd;