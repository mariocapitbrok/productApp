const ProductsBody = () => {
  return <div></div>
}

export default ProductsBody
