const Home = () => {
  return (
    <div>
      <h1>Products app</h1>
      <h3>Welcome</h3>
    </div>
  )
}

export default Home
;<div>
  <h1>Products app</h1>
  <h3>Welcome</h3>
</div>
