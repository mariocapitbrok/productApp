const Body = () => {
  return <></>
}

export default Body
