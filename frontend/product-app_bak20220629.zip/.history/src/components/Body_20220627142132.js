const Body = () => {
  return (
    <div>
      <ProductsHeader />
      <ProductsBody />
      <ProductsFooter />
    </div>
  )
}

export default Body
