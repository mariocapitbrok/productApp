import Products from './Products'

const Body = () => {
  return (
    <div>
      <Products />
    </div>
  )
}

export default Body
