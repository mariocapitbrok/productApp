const ProductsBody = () => {
  return <></>
}

export default ProductsBody
