import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'

const Header = () => {
  return <div className="header"></div>
}

export default Header
