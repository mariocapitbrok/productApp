const Home = () => {
  return (
    <div className="home">
      <h1>Products app</h1>
      <h3>Welcome to Home</h3>
    </div>
  )
}

export default Home
;<div>
  <h1>Products app</h1>
  <h3>Welcome</h3>
</div>
